namespace java com.hyx.learn  
  
service DemoService{  
    string sayHi(1:string name);  
} 